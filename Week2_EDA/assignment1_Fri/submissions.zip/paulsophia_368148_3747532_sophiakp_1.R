##Excercise 1

setwd("/Users/Sophia.Kathryn/Desktop/StatsLabs/")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
Rays_SP$HR9
ans=list("C",6)
matrix(data=c(1:24), nrow=4, ncol=6, byrow=TRUE)

##Excercise 2
hist(Rays_SP$K9, probability=TRUE)
lines(density(Rays_SP$K9, na.rm=TRUE), col="blue")
shapiro.test(Rays_SP$K9)

##Excercise 3
hist(iris$Sepal.Length)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="blue")
shapiro.test(iris$Sepal.Length)

hist(iris$Sepal.Width)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="blue")
shapiro.test(iris$Sepal.Width)

hist(iris$Petal.Length)
lines(density(iris$Petal.Length, na.rm=TRUE), col="blue")
shapiro.test(iris$Petal.Length)

hist(iris$Petal.Width)
lines(density(iris$Petal.Width, na.rm=TRUE), col="blue")
shapiro.test(iris$Petal.Width)
