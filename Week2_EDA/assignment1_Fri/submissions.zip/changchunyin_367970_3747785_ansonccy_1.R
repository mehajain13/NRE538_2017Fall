
setwd("C:/Users/anson/Desktop/NRE538/Lab2")

### EX1 
Rays_SP$W
ans = list ("AA", 3)
## 
### EX2 
hist(Rays_SP$LOB, breaks=10, freq=FALSE)
lines(density(Rays_SP$LOB, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$LOB)

#according to the shapiro test, the p-value is smaller than 0.05 which means the distribution is not normally distributed.

##
### EX3
data(iris)
head(iris)
hist(iris$Sepal.Length,iris, breaks=10, freq=FALSE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)

#according to the shapiro test, the p-value is smaller than 0.05 which means the distribution is not normally distributed. 

hist(iris$Sepal.Width,breaks=10, freq=FALSE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)

#according to the shapiro test, the p-value is smaller than 0.05 which means the distribution is not normally distributed. 

hist(iris$Petal.Length, breaks=10, freq=FALSE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)

#according to the shapiro test, the p-value is smaller than 0.05 which means the distribution is not normally distributed. 

hist(iris$Petal.Width, breaks=10, freq=FALSE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)

#according to the shapiro test, the p-value is smaller than 0.05 which means the distribution is not normally distributed. 

## 