#Lauren Edson; Friday Lab NRE 538


Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")

###Exercise 1
Rays_SP$W
ans1 = list("lauren",23)
ans2 = matrix(data = c(1:12), nrow=3, ncol=4)

###

###Exercise 2
mean(Rays_SP$IP)
var(Rays_SP$IP)

hist(Rays_SP$IP, breaks=10, freq=FALSE)
hist(Rays_SP$IP, probability=TRUE)
lines(density(Rays_SP$IP, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$IP)
#W = 0.90874, p-value = 2.237e-09
qqnorm(Rays_SP$IP); qqline(Rays_SP$IP, col="Red")

###
data(iris)
head(iris)

###Exersize 3
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")

hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")

hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")

hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")

shapiro.test(iris$Sepal.Length)
#W = 0.97609, p-value = 0.01018
qqnorm(iris$Sepal.Length); qqline(iris$Sepal.Length, col="Red")

shapiro.test(iris$Sepal.Width)
#W = 0.98492, p-value = 0.1012
qqnorm(iris$Sepal.Width); qqline(iris$Sepal.Width, col="Red")

shapiro.test(iris$Petal.Length)
#W = 0.87627, p-value = 7.412e-10
qqnorm(iris$Petal.Length); qqline(iris$Petal.Length, col="Red")

shapiro.test(iris$Petal.Width)
#W = 0.90183, p-value = 1.68e-08
qqnorm(iris$Petal.Width); qqline(iris$Petal.Width, col="Red")

###