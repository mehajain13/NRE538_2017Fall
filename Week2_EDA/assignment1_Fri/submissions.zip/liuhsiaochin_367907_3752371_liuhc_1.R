###Set working directory
setwd("D:/NRE538/Lab/Week2")
Rays_SP=read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")

###Exercise 1
#1
Rays_SP$Name
#2
ans1=list("QAQ",1,3,1,4,5,2,0)
ans2=matrix(data=1:20,nrow=4,ncol=5,byrow=TRUE)

###Exercise 2
hist(Rays_SP$HRFB)
hist(Rays_SP$HRFB,probability=TRUE)
lines(density(Rays_SP$HRFB,na.rm=TRUE),col="red")
shapiro.test(Rays_SP$HRFB)
HRFB.mean=mean(Rays_SP$HRFB,na.rm=TRUE)
HRFB.sd=sd(Rays_SP$HRFB,na.rm=TRUE)
ks.test(Rays_SP$HRFB,"qnorm",HRFB.mean,HRFB.sd)
qqnorm(Rays_SP$HRFB);qqline(Rays_SP$HRFB,col="red")
qqPlot(Rays_SP$HRFB)

###Exercise 3
#Sepal.Length
hist(iris$Sepal.Length)
hist(iris$Sepal.Length,probability=TRUE)
lines(density(iris$Sepal.Length,na.rm=TRUE),col="red")
shapiro.test(iris$Sepal.Length)
Sepal.Length.mean=mean(iris$Sepal.Length,na.rm=TRUE)
Sepal.Length.sd=sd(iris$Sepal.Length,na.rm=TRUE)
ks.test(iris$Sepal.Length,"qnorm",Sepal.Length.mean,Sepal.Length.sd)
qqnorm(iris$Sepal.Length);qqline(iris$Sepal.Length,col="red")
qqPlot(iris$Sepal.Length)

#Sepal.Width
hist(iris$Sepal.Width)
hist(iris$Sepal.Width,probability=TRUE)
lines(density(iris$Sepal.Width,na.rm=TRUE),col="red")
shapiro.test(iris$Sepal.Width)
Sepal.Width.mean=mean(iris$Sepal.Width,na.rm=TRUE)
Sepal.width.sd=sd(iris$Sepal.Width,na.rm=TRUE)
ks.test(iris$Sepal.Width,"qnorm",Sepal.Width.mean,Sepal.width.sd)
qqnorm(iris$Sepal.Width);qqline(iris$Sepal.Width,col="red")
qqPlot(iris$Sepal.Width)

#Petal.Length
hist(iris$Petal.Length)
hist(iris$Petal.Length,probability=TRUE)
lines(density(iris$Petal.Length,na.rm=TRUE),col="red")
shapiro.test(iris$Petal.Length)
Petal.Length.mean=mean(iris$Petal.Length,na.rm=TRUE)
Petal.Length.sd=sd(iris$Petal.Length,na.rm=TRUE)
ks.test(iris$Petal.Length,"qnorm",Petal.Length.mean,Petal.Length.sd)
qqnorm(iris$Petal.Length);qqline(iris$Petal.Length,col="red")
qqPlot(iris$Petal.Length)

#Petal.Width
hist(iris$Petal.Width)
hist(iris$Petal.Width,probability=TRUE)
lines(density(iris$Petal.Width,na.rm=TRUE),col="red")
shapiro.test(iris$Petal.Width)
Petal.Width.mean=mean(iris$Petal.Width,na.rm=TRUE)
Petal.Width.sd=sd(iris$Petal.Width,na.rm=TRUE)
ks.test(iris$Petal.Width,"qnorm",Petal.Width.mean,Petal.Width.sd)
qqnorm(iris$Petal.Width);qqline(iris$Petal.Width,col="red")
qqPlot(iris$Petal.Width)
