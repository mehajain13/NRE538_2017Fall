setwd("//TOURVILLE/Users/jtourvil/Desktop/Stats R/stats")
data<-read.csv("RaysSP.csv", header=TRUE, fill=TRUE, sep=",")
###EX1
ans<-list("AA", 3) #List
ans1<-matrix(c("1,2,3,4,5"), 3) #Matrix
###
###EX2#Making a histogram with density function, testing for normality with Shapiro and K-S test, and plotting QQ.
hist(data$HR9, freq = FALSE)
lines(density(data$HR9, na.rm=TRUE), col="red")
shapiro.test(data$HR9)
HR9.mean<-mean(data$HR9, na.rm=TRUE)
HR9.sd<-sd(data$HR9, na.rm=TRUE)
ks.test(data$HR9, "qnorm", HR9.mean, HR9.sd)
qqnorm(data$HR9); qqline(data$HR9, col="Red")
install.packages("car")#don't run this if you already have the package installed.
library(car)
qqPlot(data$HR9)#all tests for normality failed.
###
###EX3#Making histograms for all four variables with associated Shapiro tests for normality.
hist(iris$Sepal.Length, freq = FALSE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)#p<0.05
hist(iris$Sepal.Width, freq = FALSE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)#0>0.05
hist(iris$Petal.Length, freq = FALSE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)#p<0.05
hist(iris$Petal.Width, freq = FALSE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)#p<0.05
###
