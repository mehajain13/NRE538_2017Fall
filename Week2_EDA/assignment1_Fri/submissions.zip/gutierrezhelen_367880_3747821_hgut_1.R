### Ex. 1

Rays_SP$L
ans=list("AA",3)
matrix(data=c(1:15),nrow=3, ncol=5)

###Ex. 2

hist(Rays_SP$L, probability = TRUE)
lines(density(Rays_SP$L, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$L)
####Answer: The Shapiro-Wilk test indicates that W = 0.94352,and the p-value = 9.444e-07, thus the density function of the variable "L" does not fit the normal distribution density curve.

###Ex. 3

data(iris)
head(iris)

####Variable 1: Sepal Length
hist(iris$Sepal.Length, breaks=20, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)
####Answer: The Shapiro-Wilk test indicates that W = 0.97609,and the p-value = 0.01018, thus the density function of the variable "Sepal Length" does not fit the normal distribution density curve.

####Variable 2: Sepal Width
hist(iris$Sepal.Width, breaks=20, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)
####Answer: The Shapiro-Wilk test indicates that W = 0.98942,and the p-value = 0.1012, thus because the p-value is greater than 0.05, we can say that the density function of the variable "Sepal Width" fits the normal distribution density curve.

####Variable 3: Petal Width
hist(iris$Petal.Width, breaks=20, probability = TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)
####Answer: The Shapiro-Wilk test indicates that W = 0.90183,and the p-value = 1.68e-08, thus the density function of the variable "Petal Width" does not fit the normal distribution density curve.

####Variable 4: Petal Length
hist(iris$Petal.Length, breaks=20, probability = TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)
####Answer: The Shapiro-Wilk test indicates that W = 0.87627,and the p-value = 7.412e-10, thus the density function of the variable "Petal Length" does not fit the normal distribution density curve.
