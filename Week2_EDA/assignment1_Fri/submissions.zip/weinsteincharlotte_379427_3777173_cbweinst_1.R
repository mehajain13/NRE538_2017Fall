#set working directory, read data in
setwd("/Users/Charmander/Desktop/SNRE Courses/Winter 2017/538 Statistics/Lab2")
Rays_SP = read.table("Rays_starter_1998_2015.csv", header=T, fill=T, sep=",")

# EX1

wins = Rays_SP$W
ans = list("apple", 42)
ans2 = matrix(data=NA, nrow=3, ncol=3)
matrix(data=c(1:15), nrow=3,ncol=5, byrow=TRUE)


# EX2

hist(Rays_SP$W) #frequency histogram
hist(Rays_SP$W, probability=TRUE) #density function
lines(density(Rays_SP$W, na.rm=TRUE), col="red") #adds density function line

shapiro.test(Rays_SP$W) #test normality of function using Shapiro test


# EX3

data(iris) #load iris data

#plot density functions of each of iris's 4 variables
hist(iris$Sepal.Length, probability = TRUE)
hist(iris$Sepal.Width, probability = TRUE)
hist(iris$Petal.Length, probability = TRUE)
hist(iris$Petal.Width, probability = TRUE)

#test normality of each of iris's 4 variables using Shapiro test
shapiro.test(iris$Sepal.Length)
shapiro.test(iris$Sepal.Width)
shapiro.test(iris$Petal.Length)
shapiro.test(iris$Petal.Width)
