###EX1
setwd("C:/Users/OfficeMax/Documents/NRE538")
Rays.SP = read.table("Rays_SP.csv",header=T,sep=",")
head(Rays.SP,10)
class(Rays.SP)
str(Rays.SP)
Rays.SP$Season
Rays.SP$W
list((Rays.SP$Season:Rays.SP$W))
ans = list("AA", 3)
matrix(data=c(1:15), nrow=3, ncol=5)


###EX2
hist(Rays.SP$Season, breaks=20, freq=FALSE)
lines(density(Rays.SP$Season, na.rm=TRUE), col="red")
shapiro.test(Rays.SP$Season)

###EX3
data(iris)
head(iris)
hist(iris$Sepal.Length, breaks=10, freq = FALSE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)
###p = 0.01018; we cannot assume normality
hist(iris$Sepal.Width, breaks=10, freq = FALSE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)
###p = 0.1012; we can assume normality
hist(iris$Petal.Length, breaks=10, freq = FALSE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)
###p = 7.412e-10; we cannot assume normality
hist(iris$Petal.Width, breaks=10, freq = FALSE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)
### p-value = 1.68e-08; we cannot assume normality 