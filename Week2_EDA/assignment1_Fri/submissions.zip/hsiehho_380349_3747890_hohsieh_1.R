#hohsieh_1
setwd("/Users/user/Desktop/NRE538/Lab/wk2")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")

###EX1
#1
Rays_SP$Name

#2
ex1= list(1,2,"ABC")
ex1_2= matrix(data=c(1:10),2,5)

###EX2
hist(Rays_SP$ERA)
hist(Rays_SP$ERA, probability = TRUE)
lines(density(Rays_SP$ERA, na.rm = TRUE), col="red")

shapiro.test(Rays_SP$ERA) 
#According to the shapiro test, the p-value is smaller than 0.05 
#which means it is not a normal distribution. 

###EX3
#1_Sepal.Length
data(iris)
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm = TRUE), col="red")

shapiro.test(iris$Sepal.Length) 
#According to the shapiro test, this is not a normal distribution (p-value=0.01<0.05)

#2_Sepal.Width
data(iris)
hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm = TRUE), col="red")

shapiro.test(iris$Sepal.Width)
#According to the shapiro test, we cannot said if this is a normal distribution (p-value=0.1>0.05)

#3_Petal.Length
data(iris)
hist(iris$Petal.Length)
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm = TRUE), col="red")

shapiro.test(iris$Petal.Length)
#According to the shapiro test, this is not a normal distribution (p-value<<0.05)

#4_Petal.Width
data(iris)
hist(iris$Petal.Width)
hist(iris$Petal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm = TRUE), col="red")

shapiro.test(iris$Petal.Width)
#According to the shapiro test, this is not a normal distribution (p-value<<0.05)
