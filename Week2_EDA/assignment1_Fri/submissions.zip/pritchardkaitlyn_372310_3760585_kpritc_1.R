### EXERCISE 1

setwd("/Users/katiepritchard/Desktop/NRE 538/Lab 1")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
head(Rays_SP,10)
class(Rays_SP)
str(Rays_SP)
Rays_SP$HR9
ans = list("AA", 3)
ans2 = matrix(data=c(1:15), nrow=3, ncol=5, byrow=TRUE)


### EXERCISE 2

mean(Rays_SP$HR9)
var(Rays_SP$HR9)
hist(Rays_SP$HR9, probability=TRUE)
lines(density(Rays_SP$HR9, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$HR9)
## Since the p-value is less than 0.05, we reject the null hypothesis that the data is from a normally distributed population

### EXERCISE 3
data(iris)
head(iris)
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)
## Since the p-value is 0.01 and therefore less than 0.05, we reject the null hypothesis that the data is from a normally distributed population

hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)
## Since the p-value is 0.10 and is greater than 0.05, we accept the null hypothesis that the data is from a normally distributed population

hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)
## Since the p-value is less than 0.05, we reject the null hypothesis that the data is from a normally distributed population

hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)
## Since the p-value is less than 0.05, we reject the null hypothesis that the data is from a normally distributed population