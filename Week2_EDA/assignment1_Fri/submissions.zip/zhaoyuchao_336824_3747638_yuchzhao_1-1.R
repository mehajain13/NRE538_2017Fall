### EX1
setwd("~/Desktop/LAB2")
Rays_SP=read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
Rays_SP$LOB
list ("AA",3)
matrix(data=c(1:16),nrow=4,ncol=4, byrow=TRUE)

### EX2
hist(Rays_SP$LOB, breaks=20, freq=FALSE) 
qqnorm(Rays_SP$LOB) 
qqline(Rays_SP$GB, col="Red")

### EX3
data(iris)
hist(iris$Sepal.Length, breaks=20, freq=FALSE)
qqnorm(iris$Sepal.Length); qqline(iris$Sepal.Length, col="Red")
### this vriable is not normally distributued
hist(iris$Sepal.Width, breaks=20, freq=FALSE)
qqnorm(iris$Sepal.Width); qqline(iris$Sepal.Width, col="Red")
### this variable is not normally distributed
hist(iris$Petal.Length, breaks=20, freq=FALSE)
qqnorm(iris$Petal.Length); qqline(iris$Petal.Length, col="Red")
### this variable is pretty off
hist(iris$Petal.Width, breaks=20, freq=FALSE)
qqnorm(iris$Petal.Width); qqline(iris$Petal.Width, col="Red")
### this variable is pretty off
