setwd("C:/Users/kteppert/Dropbox/Grad School/Winter2017/538/Labs/Week2")
Rays_SP = read.table("Rays_starter_1998_2015.csv", header=T,fill=T,sep=",")

##EX1

Rays_SP$W
mylist = list("character entry", 51)

matrix(c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), nrow=10, ncol=5, byrow=TRUE) 
    #the vector could also be denoted as c(1:10)

##EX2

hist(Rays_SP$W, freq=FALSE) 
lines(density(Rays_SP$W, na.rm=TRUE), col="red")

##EX3

##Sepal.Width
hist(iris$Sepal.Width, freq=FALSE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
qqnorm(iris$Sepal.Width); qqline(iris$Sepal.Width, col="red") 
  #According to the qq test, this is not normally distrubited; although, it may be close. 

##Sepal.Length
hist(iris$Sepal.Length, freq=FALSE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
qqnorm(iris$Sepal.Length); qqline(iris$Sepal.Length, col="red")
  #According to this qq test, this is not normally distributed

##Petal.Length
hist(iris$Petal.Length, freq=FALSE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
qqnorm(iris$Petal.Length); qqline(iris$Petal.Length, col="red")
  #According to this qq test, this is not normally distrubted

##Petal.Width
hist(iris$Petal.Width, freq=FALSE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
qqnorm(iris$Petal.Width); qqline(iris$Petal.Width, col="red")
  #According to this qq test, this is not normally distrubted 
