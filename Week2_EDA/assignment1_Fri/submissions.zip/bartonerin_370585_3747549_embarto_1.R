setwd("/Users/erinmbarton/Documents/R Work/Class Work/Statistics Class/Lab Work/Stats_Lab01")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")


#Exercise 1:
wins<-Rays_SP$W
CA_wins<-list("Chris Archer", 12)
CA_wins
mymatrix<-matrix(data=c(1:15), nrow=3,ncol=5, byrow=TRUE)
mymatrix

#Exercise 2: 
hist(Rays_SP$BB9)
hist(Rays_SP$BB9, probability=TRUE)
lines(density(Rays_SP$BB9, na.rm=TRUE), col="red")
library(car)
shapiro.test(Rays_SP$BB9)
#Shapiro-Wilk normality test
#data:  Rays_SP$BB9
#W = 0.8733, p-value = 1.818e-11 
#According to this test the data is not normal, as the p-value is less than 0.05

#Exercise 3: 
data(iris)
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE),col="red")
shapiro.test(iris$Sepal.Length)
#Shapiro-Wilk normality test
#data:  iris$Sepal.Length
#W = 0.97609, p-value = 0.01018
#According to this test the sepal length is not normal, as p<0.05

hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE),col="red")
shapiro.test(iris$Sepal.Width)
#Shapiro-Wilk normality test
#data:  iris$Sepal.Width
#W = 0.98492, p-value = 0.1012
#According to this test the sepal width is normal, as p>0.05

hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE),col="red")
shapiro.test(iris$Petal.Length)
#Shapiro-Wilk normality test
#data:  iris$Petal.Length
#W = 0.87627, p-value = 7.412e-10
#According to this test the petal length is not normal, as p<0.05

hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE),col="red")
shapiro.test(iris$Petal.Width)
#Shapiro-Wilk normality test
#data:  iris$Petal.Width
#W = 0.90183, p-value = 1.68e-08
#According to this test the petal width is not normal, as p<0.05
