setwd("C:/Users/pshetty/Downloads")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")

## Exercise 1

Rays_SP$WAR

thelist = list("AA",3)
thelist

thematrix = matrix(c("a","P","S",1,2,3), nrow=3, ncol=2)
thematrix


## Exercise 2

hist(Rays_SP$WAR,freq=FALSE)
lines(density(Rays_SP$WAR, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$WAR)
# p-value = 1.79e-11 // As the p-value is less than 0.05, it doesnt follow normal distribution

##Exercise 3

data(iris)

hist(iris$Sepal.Length,freq=FALSE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)
##p-value = 0.01018


hist(iris$Sepal.Width,freq=FALSE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)
##p-value = 0.1012  // As the p-value is more than 0.05, it  follows normal distribution

hist(iris$Petal.Length,freq=FALSE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)
## p-value = 7.412e-10  // As the p-value is less than 0.05, it doesnt follow normal distribution

hist(iris$Petal.Width,freq=FALSE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)
##  p-value = 1.68e-08  // As the p-value is less than 0.05, it doesnt follow normal distribution
