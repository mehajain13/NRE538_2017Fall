## Exercise 1

setwd("/docs/umich/coursework/538/labs/lab01")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
Rays_list = list(Rays_SP$Season,Rays_SP$Name)
Rays_matrix = matrix(data=Rays_SP$WAR,nrow=4,ncol=47,byrow=TRUE)


## Exercise 2

hist(Rays_SP$WAR, probability=TRUE)
shapiro.test(Rays_SP$WAR)


## Exercise 3

hist(iris$Sepal.Length, probability=TRUE)
shapiro.test(iris$Sepal.Length)

hist(iris$Sepal.Width, probability=TRUE)
shapiro.test(iris$Sepal.Width)

hist(iris$Petal.Length, probability=TRUE)
shapiro.test(iris$Petal.Length)

hist(iris$Petal.Width, probability=TRUE)
shapiro.test(iris$Petal.Width)