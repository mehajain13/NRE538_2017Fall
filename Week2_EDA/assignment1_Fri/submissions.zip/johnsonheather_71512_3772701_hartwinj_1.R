# "data.frame" is a table which stores data in the form of equal length vectors.  It combines the vectors of different types of data.

# The output of each variable designates data as categorical or numerical.

# Merge joins and combines data using common columns and common rows using two different datasets.

# The differences between the two histograms are: 
#       - One is a frequency histogram which shows the number of times a value was observed in that particular "bin"
#       - The other is a Density Histogram which the "bins" are not of equal widtth so the area of the bin is proportional to the frequency of values in the bin.  
#         Density histograms are smoothed over by kerneling and a density curve is added to reflect continuous distribution.

# na.rm = counts and removes all of the missing or NA values and returns computations for existing data.

# The results from the Shapiro-Wilk normality test show pvalue=0.03491<alpha=0.05 which means the null hypothesis of the data (from the ground ball dataset) from a population which is normally distributed is rejected.
#    The W is close to 1; I think this reflects something about a large sample size but I'm not entirely sure.

# The correlation coefficient, R, measures the strength of a linear relationship between two variables and is a number between -1 and 1. 
#  Where 0 means there's no linear relationship.

# The species value isn't calculated because it is a factor or categorical data.



#Exercise 1
Rays_SP$Name
Rays_SP$Season
ans = list(nameseason=c("Name","Season"))
mymatrix=matrix(1:12,nrow=8,ncol=3,byrow=TRUE)
head(mymatrix)
head(ans)

#Exercise 2
hist(Rays_SP$W)
hist(Rays_SP$W, probability=TRUE)
lines(density(Rays_SP$W,na.rm=TRUE),col="red")
shapiro.test(Rays_SP$W)
W.mean=mean(Rays_SP$W, na.rm=TRUE)
W.sd=sd(Rays_SP$W, na.rm=TRUE)
ks.test(Rays_SP$W, "qnorm", W.mean, W.sd)
qqnorm(Rays_SP$W);qqline(Rays_SP$W,col="Red")
library(car)
qqPlot(Rays_SP$W)

#Exercise 2
hist(Rays_SP$W)
hist(Rays_SP$W, probability=TRUE)
lines(density(Rays_SP$W,na.rm=TRUE),col="red")
shapiro.test(Rays_SP$W)


#Exercise 3
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm = TRUE), col="Red")
shapiro.test(iris$Sepal.Length)
hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width,na.rm=TRUE), col="Green")
shapiro.test(iris$Sepal.Width)
hist(iris$Petal.Length)
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm = TRUE), col="blue")
shapiro.test(iris$Petal.Length)
hist(iris$Petal.Width)
hist(iris$Petal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm = TRUE), col="black")
shapiro.test(iris$Petal.Width)