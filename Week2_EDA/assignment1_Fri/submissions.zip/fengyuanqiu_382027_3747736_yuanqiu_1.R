setwd("C:/Users/Yuanqiu/Dropbox/Statistics/Lab2")
Rays_SP = read.table("Rays_starter_1998_2015.csv", header=T, fill=T, sep=",")
head(Rays_SP, 10)
class(Rays_SP)
str(Rays_SP)

###EXERCISE 1: Pick a random variable & Create a random list & matrix
Rays_SP$Season
Rays_SP$W
Rayslist=list(Rays_SP$Name)

randomlist = list("ABC, 1, 25, CD")

randommatrix = matrix(data=c(1:24), nrow=4, ncol=6, byrow=TRUE)

###EXERCISE 2

hist(Rays_SP$L, probability = T)

L.mean=mean(Rays_SP$L, na.rm=TRUE)
L.sd=sd(Rays_SP$L, na.rm=TRUE)

lines(density(Rays_SP$L, na.rm=TRUE), col="red")
ks.test(Rays_SP$L,"qnorm", L.mean, L.sd)

#####Ks TEST output:  Rays_SP$L ; D = NaN, p-value = NA ; alternative hypothesis: two-sided; Not normally distributed.

###EXERCISE 3: Create histograms

hist(iris$Sepal.Length, probability = T)
shapiro.test(iris$Sepal.Length)
#Sepal length not normally distributed, P=0.01018

hist(iris$Sepal.Width, probability = T)
shapiro.test(iris$Sepal.Width)
#Sepal width is normally distributed, p = 0.1012

hist(iris$Petal.Length, probability = T)
shapiro.test(iris$Petal.Length)
#Petal length not normally distrbuted, p = 7.412e-10

hist(iris$Petal.Width, probability = T)
shapiro.test(iris$Petal.Width)
#Petal wdith not normally distributed, p = 1.68e-08

