### Exercise 1
Rays_SP$W
ans=list(48, "Walker", "blue", 3.14, "mac and cheese", 098273049)
ans2=matrix(data=c(1:15), nrow = 3, ncol = 5, byrow=TRUE)

### Exercise 2
hist(Rays_SP$L)
hist(Rays_SP$L, probability=TRUE)
lines(density(Rays_SP$L, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$L)
# The Shapiro-Wilk test indicates that the data is not normally distributed because the p-value<0.05 (p=9.444e-07) 

### Exercise 3
data(iris)

hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)
# The Shapiro-Wilk test indicates that the data is not normally distributed because the p-value<0.05 (p=0.01018) 

hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)
# The Shapiro-Wilk test indicates that the data is normally distributed because the p-value>0.05 (p=0.1012) 

hist(iris$Petal.Length)
hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)
# The Shapiro-Wilk test indicates that the data is not normally distributed because the p-value<0.05 (p=7.412e-10) 

hist(iris$Petal.Width)
hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)
# The Shapiro-Wilk test indicates that the data is not normally distributed because the p-value<0.05 (p=1.68e-08)
