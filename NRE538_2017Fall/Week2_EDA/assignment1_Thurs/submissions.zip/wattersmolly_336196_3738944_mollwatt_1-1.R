Rays_SP = read.table("Rays_starter_1998_2015.csv",header = T,fill = T,sep = ",")

#Exercise 1

Rays_SP$W
ans = list("MOLLY",22,7)
mymatrix = matrix(1:9, nrow = 3, ncol = 3)
mymatrix

#Exercise 2

install.packages("car")
library(car)
qqPlot(Rays_SP$GB)

hist(Rays_SP$L)
hist(Rays_SP$L, probability = TRUE)
lines(density(Rays_SP$L, na.rm = TRUE), col="red")

qqPlot(Rays_SP$L)


#Exercise 3
data(iris)

hist(iris$Sepal.Length)
hist(iris$Sepal.Width)
hist(iris$Petal.Length)
hist(iris$Petal.Width)

hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm = TRUE), col="red")
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm = TRUE), col="red")
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm = TRUE), col="red")
hist(iris$Petal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm = TRUE), col="red")

qqPlot(iris$Sepal.Length)
qqPlot(iris$Sepal.Width)
qqPlot(iris$Petal.Length)
qqPlot(iris$Petal.Width)