setwd("C:/Users/Cria/Documents/Stats_Lab_2")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")

##Ex1##
Rays_SP$IP
Ans2 = list("Cria", 7)
Ans2
matrix(data=Ans2, nrow=5,ncol=10,byrow=FALSE, dimnames=NULL)
#######

install.packages("car")
library(car)

##Excersize 2##
hist(Rays_SP$L)
hist(Rays_SP$L, probability = TRUE)
lines(density(Rays_SP$L, na.rm=TRUE), col='red')
qqPlot(Rays_SP$L)

##Excersize 3##
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col='red')
qqPlot(iris$Sepal.Length)

hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col='red')
qqPlot(iris$Sepal.Width)

hist(iris$Petal.Length)
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col='red')
qqPlot(iris$Petal.Length)

hist(iris$Petal.Width)
hist(iris$Petal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col='red')
qqPlot(iris$Petal.Width)