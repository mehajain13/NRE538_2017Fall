#Exercise 1
Rays_SP$W
list ("Season, Name, W")
matrix ("Season, W")

#Exercise 2
hist(Rays_SP$BB9)
hist(Rays_SP$BB9, probability=TRUE)
lines(density(Rays_SP$BB9, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$BB9)

#Exercise 3
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)

hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)

hist(iris$Petal.Length)
hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)

hist(iris$Petal.Width)
hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)

