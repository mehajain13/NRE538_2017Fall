setwd("M:/Private/NRE538/Lab_01")

Rays_SP <- read.table("Rays_starter_1998_2015.csv",
                      header = TRUE,
                      fill = TRUE,
                      sep = ",")



### Exercise 1 ###
ex1 <- Rays_SP$BB9

L1 <- list("cat", 1)
M1 <- matrix(Rays_SP$W, nrow = 47, ncol = 4)
###  ###  ###  ###




### Exercise 2 ###
hist(Rays_SP$ERA)

hist(Rays_SP$ERA, probability = TRUE)
lines(density(Rays_SP$ERA, na.rm=TRUE), col="red")

library(car)
qqPlot(Rays_SP$ERA)
###  ###  ###  ###



### Exercise 3 ###
data("iris")
library(car)

#variable 1
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="blue")
qqPlot(iris$Sepal.Length)

#variable 2
hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="blue")
qqPlot(iris$Sepal.Width)

#variable 3
hist(iris$Petal.Length)
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="blue")
qqPlot(iris$Petal.Length)

#variable 4
hist(iris$Petal.Width)
hist(iris$Petal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="blue")
qqPlot(iris$Petal.Width)
###  ###  ###  ###


