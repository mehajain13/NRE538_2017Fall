setwd("/Users/jacaranda/Desktop/Week2_Assignment1")
Rays_SP=read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",") 
class(Rays_SP)
head(Rays_SP)
str(Rays_SP)

#Exercise1,question1
Rays_SP$W
Rays_SP$FIP
#Exercise1,question2 
C=list("Yilun",3,4)
C
A=matrix(c("I","Agree","With","You","1","3","1","4"),nrow = 2,ncol = 4,byrow = TRUE)
A
B=matrix(c(1:21),nrow = 3,ncol = 7,byrow = TRUE)
B

#Exercise2
install.packages("car")
library(car)
hist(Rays_SP$ERA)
hist(Rays_SP$ERA,probability=TRUE)
lines(density(Rays_SP$ERA,na.rm=TRUE),lty="dotted",lwd=3,col="Red")
shapiro.test(Rays_SP$ERA) #P-value<2.2e-16<0.05,not a normal distribution
ERA.mean=mean(Rays_SP$ERA)
ERA.sd=sd(Rays_SP$ERA)
qqnorm(Rays_SP$ERA)
qqline(Rays_SP$ERA,col="Red")
qqPlot(Rays_SP$ERA)
ERA.log=log(Rays_SP$ERA)[!is.na(log(Rays_SP$ERA))]
New.ERA.log=ERA.log[!is.infinite(log(Rays_SP$ERA))]
ERA.mean.log=mean(New.ERA.log)
ERA.sd.log=sd(New.ERA.log)
shapiro.test(New.ERA.log) #p-value = 1.59e-08<0.05, not a normal distribution
qqnorm(New.ERA.log)
qqline(New.ERA.log,col="Red")
qqPlot(New.ERA.log)

#Exercies3
data(iris)
hist(iris$Sepal.Length,probability = TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length) #p-value = 0.01018<0.05,not a normal distribution
hist(iris$Sepal.Width,probability = TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width) #p-value = 0.1012>0.05,this is a normal distribution
hist(iris$Petal.Length,probability = TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length) #p-value = 7.412e-10<0.05,not a normal distribution
hist(iris$Petal.Width,probability = TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width) #p-value = 1.68e-08<0.05,refuse original hypothesis,not a normal distribution
Slength.log=log(iris$Sepal.Length)[!is.na(iris$Sepal.Length)]
Swidth.log=log(iris$Sepal.Width)[!is.na(iris$Sepal.Width)]
Plength.log=log(iris$Petal.Length)[!is.na(iris$Petal.Length)]
Pwidth.log=log(iris$Petal.Width)[!is.na(iris$Petal.Width)]
shapiro.test(Slength.log) #p-value = 0.05388>0.05,accept original hypothesis, this is a normal distribution
shapiro.test(Swidth.log) #p-value = 0.3005>0.05,accept original hypothesis,this is a normal distribution
shapiro.test(Plength.log) #p-value = 2.038e-12<0.05,refuse original hypothesis,not a normal distribution 
shapiro.test(Pwidth.log) #p-value=1.59e-08<0.05,refuse original hypothesis,not a normal distribution