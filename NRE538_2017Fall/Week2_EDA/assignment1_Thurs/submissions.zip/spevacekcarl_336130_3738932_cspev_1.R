##Excersize 1
Rays_SP = read.table("Rays_starter_1998_2015.csv", header = T, fill = T, sep = ",")
ans1 = Rays_SP$W
ans2.1 = list("CARL", 5, 6)
ans2.2 = matrix(1:10, nrow = 2, ncol = 5, byrow = TRUE)

###Exercise 2
install.packages("car")
library(car)

hist(Rays_SP$W)
hist(Rays_SP$W, probability = TRUE)
lines(density(Rays_SP$GB, na.rm = TRUE), col = "red")
qqPlot(Rays_SP$W)

###Exercise 3
data("iris")

hist(iris$Sepal.Width)
hist(iris$Sepal.Length)
hist(iris$Petal.Length)
hist(iris$Petal.Width)

hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm = TRUE), col = "red")
hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm = TRUE), col = "red")
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm = TRUE), col = "red")
hist(iris$Petal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm = TRUE), col = "red")

qqPlot(iris$Sepal.Width)
qqPlot(iris$Sepal.Length)
qqPlot(iris$Petal.Length)
qqPlot(iris$Petal.Width)