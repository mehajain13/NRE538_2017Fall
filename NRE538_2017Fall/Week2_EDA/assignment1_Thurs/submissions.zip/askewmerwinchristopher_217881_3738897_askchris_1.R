# Assignment 1 
# Chris Askew-Merwin
# 1/12/2017


# Set-Up
setwd("C:/Users/Kelly/Dropbox/NRE 538 Nat. Res. Statistics/R/Lab #1")
Rays_SP = read.table("Rays_starter_1998_2015.csv", header=T,fill=T,sep=",")
head(Rays_SP)

### Exercise 1
Rays_SP$WAR
ans = list(Rays_SP$WAR, Rays_SP$Name, Rays_SP$playerid)
ans2 = matrix(data = 1:99, nrow = 33, ncol = 3)

### Exercise 2
hist(Rays_SP$K9, probability=TRUE)
lines(density(Rays_SP$K9, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$K9)
K9.mean = mean(Rays_SP$K9, na.rm=TRUE)
K9.sd = sd(Rays_SP$K9, na.rm=TRUE)
ks.test(Rays_SP$K9, "qnorm", K9.mean, K9.sd)
qqnorm(Rays_SP$K9); qqline(Rays_SP$K9, col="red")
qqPlot(Rays_SP$K9)

### Exercise 3

# set-Up
data(iris)
install.packages("car")
library(car)
qqPlot(Rays_SP$GB)

# Sepal.Length
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
qqPlot(iris$Sepal.Length)

# Sepal.Width
hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
qqPlot(iris$Sepal.Width)

# Petal.Length
hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
qqPlot(iris$Petal.Length)

# Petal.Width
hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
qqPlot(iris$Petal.Width)
