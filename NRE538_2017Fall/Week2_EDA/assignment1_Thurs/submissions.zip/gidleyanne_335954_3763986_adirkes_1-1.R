# NRE538 Week 2 Lab
# adirkes

#setwd("C:/Users/adirkes.UMROOT/Downloads/week2")
Rays_SP=read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
#head(Rays_SP,4)

#class(Rays_SP)

# Exercise 1
Rays_SP$playerid
mylist = list("NRE538",4,"ME542",3,"ME566",3,"MATH404",3,"NRE539",2,"ME433",3)
mymatrix = matrix(mylist,nrow=2,ncol=6)
mylist
mymatrix
#class(mymatrix) #result: "matrix" 
mymatrix_int = matrix(c(1:18),nrow=6,ncol=3)
mymatrix_int

# 4.1 order()
#SP.ord = Rays_SP[order(Rays_SP$Season),]
#SP.ord.rev = Rays_SP[order(Rays_SP$Season, decreasing=TRUE),]
#head(SP.ord)
#head(SP.ord.rev)

# 4.2 subset()
#SP.sub = subset(Rays_SP, ERA<2.5)
#print(SP.sub)
#SP.sub.1 = subset(Rays_SP, ERA<2.5, select=c(Season, Name, W, L))
#print(SP.sub.1)

# 4.3 r/cbind()
# SP.sub.2 = subset(Rays_SP, ERA<3)
# SP.sub.3 = subset(Rays_SP, ERA>=3 & ERA<4)
# rbind(SP.sub.2, SP.sub.3)
# SP.sub.4 = subset(Rays_SP, ERA<3, select=c(Season, Name, W, L))
# SP.sub.5 = subset(Rays_SP, ERA<3, select=c(G, GS, IP))
# cbind(SP.sub.4, SP.sub.5)

# 4.4 merge()
#merge(SP.sub.2, SP.sub.3, by.x="Season", by.y="Season")

# 5 Exploratory Data Analysis
# 5.1 Very basic statistics
# mean(Rays_SP$G)
# var(Rays_SP$G)

# 5.2 Distribution of one variable
# hist(Rays_SP$GB)
# hist(Rays_SP$GB, probability=TRUE)
# lines(density(Rays_SP$GB, na.rm=TRUE), col="red")
# shapiro.test(Rays_SP$GB)
# GB.mean = mean(Rays_SP$GB, na.rm=TRUE)
# GB.sd = sd(Rays_SP$GB, na.rm=TRUE)
# ks.test(Rays_SP$GB, "qnorm", GB.mean, GB.sd) #note: ties should not be present for the Kolmogorov-Smirnov test
# qqnorm(Rays_SP$GB); qqline(Rays_SP$GB, col="Red")
# install.packages("car")
# library(car)
# qqPlot(Rays_SP$GB)

# Exercise 2
#hist(Rays_SP$BABIP)
hist(Rays_SP$BABIP,probability=TRUE,main="Histogram of BABIP")
lines(density(Rays_SP$BABIP, na.rm=TRUE), col="blue")
shapiro.test(unique(Rays_SP$BABIP)) # p<<0.01
GB.mean2 = mean(Rays_SP$BABIP, na.rm=TRUE)
GB.sd2 = sd(Rays_SP$BABIP, na.rm=TRUE)
ks.test(unique(Rays_SP$BABIP), "qnorm", GB.mean2, GB.sd2) #note: ties should not be present for the Kolmogorov-Smirnov test
qqnorm(Rays_SP$BABIP); qqline(Rays_SP$BABIP, col="Red")
install.packages("car")
library(car)
qqPlot(Rays_SP$BABIP)

# 5.3 Relationship between two variables
# data(iris)
# head(iris)
# plot(iris$Sepal.Length~iris$Sepal.Width)
# cor(iris$Sepal.Length,iris$Sepal.Width)
# pairs(iris) #note: species is not numeric value
# cor(iris[,1:4]) #exclude species data

# Exercise 3

hist(iris$Sepal.Length,freq=FALSE,main="Histogram of Iris Sepal Lengths", xlab="Sepal Length")
lines(density(iris$Sepal.Length,na.rm=TRUE), col="violet")
shapiro.test(unique(iris$Sepal.Length)) # p = 0.01018

hist(iris$Sepal.Width,freq=FALSE,main="Histogram of Iris Sepal Widths", xlab="Sepal Length")
lines(density(iris$Sepal.Width,na.rm=TRUE), col="violet")
shapiro.test(unique(iris$Sepal.Width)) # p = 0.1012

hist(iris$Petal.Length,freq=FALSE,main="Histogram of Iris Petal Lengths", xlab="Petal Length")
lines(density(iris$Petal.Length,na.rm=TRUE), col="violet")
shapiro.test(unique(iris$Petal.Length)) # p << 0.01

hist(iris$Petal.Width,freq=FALSE,main="Histogram of Iris Petal Widths", xlab="Petal Width")
lines(density(iris$Petal.Width,na.rm=TRUE), col="violet")
shapiro.test(unique(iris$Petal.Width)) # p << 0.01
