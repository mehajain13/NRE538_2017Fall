#Exercise 1
Rays_starter_1998_2015$W
list(Rays_starter_1998_2015$Season, Rays_starter_1998_2015$Name)
matrix(c(Rays_starter_1998_2015$Season, Rays_starter_1998_2015$Name))

#Exercise2
hist(Rays_starter_1998_2015$W)
hist(Rays_starter_1998_2015$W, probability = TRUE)
lines(density(Rays_starter_1998_2015$W, na.rm = TRUE), col="red")
shapiro.test(Rays_starter_1998_2015$W)
qqPlot(Rays_starter_1998_2015$W)

#Exercise3
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm = TRUE), col="red")
shapiro.test(iris$Sepal.Length)
hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm = TRUE), col="red")
shapiro.test(iris$Sepal.Width)
hist(iris$Petal.Length)
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm = TRUE), col="red")
shapiro.test(iris$Petal.Length)
hist(iris$Petal.Width)
hist(iris$Petal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm = TRUE), col="red")
shapiro.test(iris$Petal.Width)