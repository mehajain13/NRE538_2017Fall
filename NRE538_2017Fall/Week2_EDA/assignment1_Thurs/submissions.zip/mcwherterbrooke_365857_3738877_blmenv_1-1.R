#Exercise1#
Rays_SP$Name #select variable
list("GS",10) #list
matrix(1:12,4,3,byrow=FALSE) #matrix
#End Exercise1#


#Excercise2#
hist(Rays_SP$BB9) #frequency
hist(Rays_SP$BB9,freq = FALSE) #density
lines(density(Rays_SP$BB9, na.rm=TRUE), col="red")

##is the ditribution normal?#
shapiro.test(Rays_SP$BB9)

#End Exercise 2#


#Exercise3#

#Variable Sepal.width#
hist(iris$Sepal.Width) #frequency
hist(iris$Sepal.Width,freq = FALSE) #density
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width) #normality#

#variable Sepal.length#
hist(iris$Sepal.Length) #frequency
hist(iris$Sepal.Length,freq = FALSE) #density
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length) #normality#

#variable petal.length#
hist(iris$Petal.Length) #frequency
hist(iris$Petal.Length,freq = FALSE) #density
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length) #normality#

#variable petal.width#
hist(iris$Petal.Width) #frequency
hist(iris$Petal.Width,freq = FALSE) #density
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width) #normality#