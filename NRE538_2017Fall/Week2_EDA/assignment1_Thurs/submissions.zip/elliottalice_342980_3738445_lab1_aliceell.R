setwd('nre538/')
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")

##Exercise 1
#1. 
Rays_SP$Name
#2.
list("barn owl",19,"hawk")
matrix(
  c(1,2,3,4,5),
  nrow=2,
  ncol=5
)

##Exercise 2
hist(Rays_SP$W, probability=TRUE)
shapiro.test(Rays_SP$W)

##Exercise 3
hist(iris$Sepal.Length)
shapiro.test(iris$Sepal.Length)
hist(iris$Sepal.Width)
shapiro.test(iris$Sepal.Length)
hist(iris$Petal.Length)
shapiro.test(iris$Sepal.Length)
hist(iris$Petal.Width)
shapiro.test(iris$Sepal.Length)