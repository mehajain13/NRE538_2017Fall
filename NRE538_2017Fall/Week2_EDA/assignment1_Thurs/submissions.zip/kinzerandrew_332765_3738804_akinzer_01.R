Rays_sp=read.csv("Rays_starter_1998_2015.csv", header=TRUE, fill=TRUE, sep=",")

#Exercise 1

ans1lob=Rays_sp$LOB

ans2 = list("Land Rover", 3, 2017 )

matrix1=matrix(data=1:20, nrow=10, ncol=2,)


#Exercise 2

hist(Rays_sp$WAR)
hist(Rays_sp$WAR, probability=TRUE)
lines(density(Rays_sp$WAR, na.rm=TRUE), col="red")

qqPlot(Rays_sp$WAR, main="QQ Plot of WAR")

#Exercise3

hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")

qqPlot(iris$Sepal.Length, main="QQ Plot of Sepal Lenght")

hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")

qqPlot(iris$Sepal.Width, main="QQ Plot of Sepal Width")

hist(iris$Petal.Length)
hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")

qqPlot(iris$Petal.Length, main="QQ Plot of Petal Length")

hist(iris$Petal.Width)
hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")

qqPlot(iris$Petal.Width, main="QQ Plot of Petal Width")