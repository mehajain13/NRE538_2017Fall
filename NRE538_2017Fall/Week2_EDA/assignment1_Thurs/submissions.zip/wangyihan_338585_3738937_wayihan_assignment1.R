setwd("M:/NRE538/lab 2/")
Rays_SP=read.table("Rays_starter_1998_2015.csv", header=T,fill=T,sep=",")
head(Rays_SP)
class(Rays_SP)
str(Rays_SP)

#Exercise1#
Rays_SP$Season
list("Yihan",10)
matrix(1:12,4,3,byrow=FALSE)
#End of exercise#

4.1 #order#
SP.ord = Rays_SP[order(Rays_SP$Season),]
SP.ord.rev = Rays_SP[order(Rays_SP$Season,decreasing = TRUE),]
head(SP.ord)

SP.sub = subset(Rays_SP, ERA<2.5)
print(SP.sub)
SP.sub.1 = subset(Rays_SP, ERA<2.5, select=c(Season, Name, W, L))
print(SP.sub.1)

#4.3 r/cbind()#
SP.sub.2 = subset(Rays_SP, ERA<3)
SP.sub.3 = subset(Rays_SP, ERA>3 & ERA<4)
rbind(SP.sub.2, SP.sub.3)

SP.sub.4 = subset(Rays_SP, ERA<3, select=c(Season, Name, W, L))
SP.sub.5 = subset(Rays_SP, ERA<3, select = c(G, GS, IP))
cbind(SP.sub.4, SP.sub.5)

#4.4 merge
merge(SP.sub.2, SP.sub.3, by.x = "Season", by.y = "Season")

hist(Rays_SP$GB)
hist(Rays_SP$GB, freq = FALSE)
lines(density(Rays_SP$GB, na.rm = TRUE), col="red")

shapiro.test(Rays_SP$GB)
install.packages("car")
library(car)
qqPlot(Rays_SP$GB)

#Exercise2#
data(iris)
head(iris)

plot(iris$Sepal.Length~iris$Sepal.Width)
cor(iris$Sepal.Length, iris$Sepal.Width)
pairs(iris)
cor(iris[,1:4])

#Exercise3#
hist(iris$Sepal.Length)
hist(iris$Sepal.Width)
hist(iris$Petal.Length)
hist(iris$Petal.Width)

hist(iris$Sepal.Length, freq = FALSE)
lines(density(iris$Sepal.Length, na.rm = TRUE), col="red")
hist(iris$Sepal.Width, freq = FALSE)
lines(density(iris$Sepal.Width, na.rm = TRUE), col="red")
hist(iris$Petal.Width, freq = FALSE)
lines(density(iris$Petal.Width, na.rm = TRUE), col="red")
hist(iris$Petal.Length, freq = FALSE)
lines(density(iris$Petal.Length, na.rm = TRUE), col="red")

qqPlot(iris$Sepal.Length)
qqPlot(iris$Sepal.Width)
qqPlot(iris$Petal.Length)
qqPlot(iris$Petal.Width)
