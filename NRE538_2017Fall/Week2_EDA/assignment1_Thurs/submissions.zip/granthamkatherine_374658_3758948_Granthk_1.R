Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
head(Rays_SP)
class(Rays_SP)
str(Rays_SP)
View(Rays_SP)
Rays_SP$Season
Rays_SP$W
list(Rays_SP$Name, Rays_SP$SV)
matrix(Rays_SP$Name)

# Excercise1

list("Katie", "Jacob",4,8)
c("Katie", "Jacob", "Mel, Kim")
matrix(data=c("Katie", "Jacob", "Mel", "Kim"), nrow = 1, ncol = 4)


#Section 4.1
SP.ord = Rays_SP[order(Rays_SP$Season),]
head(SP.ord)

SP.ord.rev = Rays_SP[order(Rays_SP$Season, decreasing=TRUE),]
head(SP.ord.rev)

#Section 4.2
SP.sub = subset(Rays_SP, ERA<4.5)
print(SP.sub)

SP.sub.1 = subset(Rays_SP, ERA<4.5, select=c(Season, Name, W, L))
print(SP.sub.1)

#Section 4.3
SP.sub.2 = subset(Rays_SP, ERA<3)
SP.sub.3 = subset(Rays_SP, ERA>=3 & ERA<4)
rbind(SP.sub.2, SP.sub.3)

SP.sub.4 = subset(Rays_SP, ERA<3, select=c(Season, Name, W, L))
SP.sub.5 = subset(Rays_SP, ERA<3, select=c(G, GS, IP))
cbind(SP.sub.4, SP.sub.5)

#Section 4.4
merge(SP.sub.2, SP.sub.3, by.x="Season", by.y="Season")

#Section 5

#Section 5.1
mean(Rays_SP$G)
var(Rays_SP$G)
#Section 5.2
hist(Rays_SP$GB)
hist(Rays_SP$GB, probability=TRUE)
lines(density(Rays_SP$GB, na.rm=TRUE), col="red")

shapiro.test(Rays_SP$GB)

GB.mean=mean(Rays_SP$GB, na.rm=TRUE)
GB.sd=sd(Rays_SP$GB, na.rm=TRUE)
ks.test(Rays_SP$GB, "qnorm", GB.mean, GB.sd)

qqnorm(Rays_SP$GB); qqline(Rays_SP$GB, col="Red")

install.packages("car")
library(car)
qqPlot(Rays_SP$GB)

hist(Rays_SP$IP)
hist(Rays_SP$IP, probability = TRUE)
lines(density(Rays_SP$IP, na.rm = TRUE), col="red")
shapiro.test(Rays_SP$IP)
qqnorm(Rays_SP$IP); qqline(Rays_SP$IP, col="Red")

#Section 5.3
data("iris")
head(iris)
plot(iris$Sepal.Length~iris$Sepal.Width)
cor(iris$Sepal.Length,iris$Sepal.Width)
pairs(iris)
cor(iris[,1:4])

#Exercise 3
#Sepal Length:
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability = TRUE)
lines(density(iris$Sepal.Length, na.rm = TRUE), col="red")
mean = mean(iris$Sepal.Length)
sd = sd(iris$Sepal.Length)
ks.test(iris$Sepal.Length, "qnorm", mean, sd)

#Sepal Width
hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Sepal.Width, na.rm = TRUE), col="red")
mean = mean(iris$Sepal.Width)
sd = sd(iris$Sepal.Width)

#Petal Length 
hist(iris$Petal.Length)
hist(iris$Petal.Length, probability = TRUE)
lines(density(iris$Petal.Length, na.rm = TRUE), col="red")
mean = mean(iris$Petal.Length)
sd = sd(iris$Petal.Length)
install.packages("car")
library(car)
qqPlot(iris$Petal.Length)

#Petal Width
hist(iris$Petal.Width)
hist(iris$Sepal.Width, probability = TRUE)
lines(density(iris$Petal.Width, na.rm = TRUE), col="red")
mean = mean(iris$Petal.Width)
sd = sd(iris$Petal.Width)
qqnorm(iris$Petal.Width);qqline(iris$Petal.Width, col="red")
