###EXERCISE 1
##1.
Rays_SP$Season

##2.
myList=list("a","b","c",1,2,3)
myList

myLabMatrix= matrix(data = 1:6, nrow = 2, ncol = 3)
myLabMatrix

###EXERCISE 2
##Plot the histogram of another variable plus density function and test the normality of it.
hist(Rays_SP$HR9)
hist(Rays_SP$HR9, probability=TRUE)
lines(density(Rays_SP$HR9, na.rm=TRUE), col="red")

qqnorm(Rays_SP$HR9); qqline(Rays_SP$HR9, col="Red")
#OR
library(car)
qqPlot(Rays_SP$HR9)

###EXERCISE 3
##Plot four histograms for each of the four variables in the Iris flower data set (with density functions) and check the normality of them.
hist(iris$Sepal.Length)
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
qqnorm(iris$Sepal.Length); qqline(iris$Sepal.Length, col="Red")

hist(iris$Sepal.Width)
hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
qqnorm(iris$Sepal.Width); qqline(iris$Sepal.Width, col="Red")

hist(iris$Petal.Length)
hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
qqnorm(iris$Petal.Length); qqline(iris$Petal.Length, col="Red")

hist(iris$Petal.Width)
hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
qqnorm(iris$Petal.Width); qqline(iris$Petal.Width, col="Red")