#Exercise 1
Rays_SP=read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
ans1=Rays_SP$W
ans2.list=list("Katie",TRUE,8)
ans2.matrix=matrix(data=ans2.list,nrow=5,ncol=6,byrow=FALSE)
####

#Exercise 2
hist(Rays_SP$W)
hist(Rays_SP$W, probability=TRUE)
lines(density(Rays_SP$W, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$W)
library(car)
qqnorm(Rays_SP$W); qqline(Rays_SP$W, col="Red")
qqPlot(Rays_SP$W)
#just practicing how to use more than one test here#
####

#Exercise 3
data(iris)
head(iris)
hist(iris$"Sepal.Length")
hist(iris$"Sepal.Length", probability=TRUE)
lines(density(iris$"Sepal.Length", na.rm=TRUE), col="red")
shapiro.test(iris$"Sepal.Length")

hist(iris$"Sepal.Width")
hist(iris$"Sepal.Width", probability=TRUE)
lines(density(iris$"Sepal.Width", na.rm=TRUE), col="red")
shapiro.test(iris$"Sepal.Width")

hist(iris$"Petal.Length")
hist(iris$"Petal.Length", probability=TRUE)
lines(density(iris$"Petal.Length", na.rm=TRUE), col="red")
shapiro.test(iris$"Petal.Length")

hist(iris$"Petal.Width")
hist(iris$"Petal.Width", probability=TRUE)
lines(density(iris$"Petal.Width", na.rm=TRUE), col="red")
shapiro.test(iris$"Petal.Width")
####
