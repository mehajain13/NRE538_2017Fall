setwd("~/Documents/Statistics/Lab 2")
read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
setwd("~/Documents/Statistics/Lab 2")
read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
class(Rays_SP)
str(Rays_SP)

Exercise 1
Rays_SP$L
list("fruit", "fries", 5)
mdat=matrix(c(1,2,3, 4,5,6), nrow=2, ncol=3, byrow=TRUE, dimnames=list(c("row1","row2"),c("C.1","C.2","C.3")))
matrix1=matrix(c("apple","banana","kiwi", "pepper","corn","pea"), nrow=2, ncol=3, byrow=TRUE, dimnames=list(c("fruit","vegetable"),c("red","yellow","green")))

Exercise 2
hist(Rays_SP$L)
hist(Rays_SP$L,freq=FALSE)
hist(Rays_SP$L, probability=TRUE)
lines(density(Rays_SP$L, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$L)

Exercise 3
hist(iris$Sepal.Length)
hist(iris$Sepal.Length,freq=FALSE)
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length,na.rm=TRUE), col="red")

hist(iris$Sepal.Width)
hist(iris$Sepal.Width,freq=FALSE)
hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width,na.rm=TRUE), col="red")

hist(iris$Petal.Length)
hist(iris$Petal.Length,freq=FALSE)
hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length,na.rm=TRUE), col="red")

hist(iris$Petal.Width)
hist(iris$Petal.Width,freq=FALSE)
hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width,na.rm=TRUE), col="red")

shapiro.test(iris$Sepal.Length)
shapiro.test(iris$Sepal.Width)
shapiro.test(iris$Petal.Length)
shapiro.test(iris$Petal.Width)
