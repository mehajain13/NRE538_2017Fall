setwd("~/Documents/MICHIGAN/538 stats/Lab 2")

Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
head(Rays_SP)


#EXERCISE 1.1
Rays_SP$LOB
#EXERCISE 1.2
newlist=list(Rays_SP$Season,Rays_SP$W)

newmatrix=as.matrix(Rays_SP[,3:4])
newmatrix1 = as.matrix(Rays_SP[c("Season","W")])
newmatrix2= matrix(c(1,2,3,4,5,6),nrow=3,ncol=2)


#EXERCISE 2
hist(Rays_SP$LOB)
hist(Rays_SP$LOB,probability=TRUE)
lines(density(Rays_SP$LOB,na.rm=TRUE),col="red")
shapiro.test(Rays_SP$LOB) #normally distributed

LOB.mean = mean(Rays_SP$LOB,na.rm=TRUE)
LOB.sd = sd(Rays_SP$LOB, na.rm=TRUE)
ks.test(Rays_SP$LOB,"qnorm",LOB.mean,LOB.sd)

qqPlot(Rays_SP$LOB)


#EXERCISE 3
hist(iris$Sepal.Length)
hist(iris$Sepal.Length,probability=TRUE)
lines(density(iris$Sepal.Length),col="red")
shapiro.test(iris$Sepal.Length) #p = 0.01 -> NOT normally distributed


hist(iris$Sepal.Width)
hist(iris$Sepal.Width,probability=TRUE)
lines(density(iris$Sepal.Width),col="red")
shapiro.test(iris$Sepal.Width) #p = 0.10 -> could be normally distributed

hist(iris$Petal.Length)
hist(iris$Petal.Length,probability=TRUE,ylim=c(0,1))
lines(density(iris$Sepal.Width),col="red")
shapiro.test(iris$Petal.Length) #p << 0.01 -> NOT normally distributed

hist(iris$Petal.Width)
hist(iris$Petal.Width,probability=TRUE)
lines(density(iris$Petal.Width),col="red")
shapiro.test(iris$Petal.Width) #p << 0.01 -> NOT normally distributed
