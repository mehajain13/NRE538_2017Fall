setwd("")
read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
Rays_SP = read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
head(Rays_SP)
head(Rays_SP,10)
View(Rays_SP)
head(Rays_SP,10)
class(Rays_SP)
str(Rays_SP)

Rays_SP$ERA

###Exercise 1
list("Alex","Sam",19,15)

matrix(data=c("Alex","Sam","Rachel","Liz"), nrow = 2,ncol = 2)



SP.ord = Rays_SP[order(Rays_SP$Season),]
Sp.ord.rev = Rays_SP[order(Rays_SP$Season, decreasing=TRUE),]
head(SP.ord,50)

SP.sub = subset(Rays_SP, ERA<2.5)

SP.sub.1 = subset(Rays_SP, ERA<2.5, select=c(Season, Name, W, L))
print(SP.sub.1)

SP.sub.2 = subset(Rays_SP, ERA<3)
SP.sub.3 = subset(Rays_SP, ERA>=3 & ERA<4)
rbind(SP.sub.2, SP.sub.3)

merge(SP.sub.2, SP.sub.3, by.x="Season", by.y="Season")

mean(Rays_SP$G)

var(Rays_SP$G)

hist(Rays_SP$GB)

hist(Rays_SP$GB, probability=TRUE)
lines(density(Rays_SP$GB, na.rm=TRUE), col="orange")

shapiro.test(Rays_SP$GB)

GB.mean=mean(Rays_SP$GB, na.rm=TRUE)
GB.sd=sd(Rays_SP$GB, na.rm=TRUE)
ks.test(Rays_SP$GB, "qnorm", GB.mean, GB.sd)

qqnorm(Rays_SP$GB); qqline(Rays_SP$GB, col="orange")

install.packages("car")

library(car)
qqPlot(Rays_SP$GB)

###Exercise 2, using ERA

mean(Rays_SP$ERA)

var(Rays_SP$ERA)

hist(Rays_SP$ERA)

hist(Rays_SP$ERA, probability=TRUE)
lines(density(Rays_SP$ERA, na.rm=TRUE), col="orange")

shapiro.test(Rays_SP$ERA)

GB.mean=mean(Rays_SP$ERA, na.rm=TRUE)
GB.sd=sd(Rays_SP$ERA, na.rm=TRUE)
ks.test(Rays_SP$ERA, "qnorm", ERA.mean, ERA.sd)

qqnorm(Rays_SP$ERA); qqline(Rays_SP$ERA, col="orange")

install.packages("car")

library(car)
qqPlot(Rays_SP$GB)


data(iris)
head(iris)

plot(iris$Sepal.Length~iris$Sepal.Width)

cor(iris$Sepal.Length,iris$Sepal.Width)

pairs(iris)

plot(iris$Petal.Length~iris$Petal.Width)

cor(iris$Petal.Length,iris$Petal.Width)

###Exercise 3

hist(iris$Sepal.Length, probability=TRUE)

lines(density(iris$Sepal.Length, na.rm=TRUE), col="orange")

shapiro.test(iris$Sepal.Length)

##
hist(iris$Sepal.Width, probability=TRUE)

lines(density(iris$Sepal.Width, na.rm=TRUE), col="orange")

shapiro.test(iris$Sepal.Width)

##
hist(iris$Petal.Length, probability=TRUE)

lines(density(iris$Petal.Length, na.rm=TRUE), col="orange")

shapiro.test(iris$Petal.Length)

##
hist(iris$Petal.Width, probability=TRUE)

lines(density(iris$Petal.Width, na.rm=TRUE), col="orange")

qqnorm(iris$Petal.Width); qqline(iris$Petal.Width, col="orange")

