# STEP 1

setwd("~/Desktop/Winter 2017/NRE 538/Lab 1")
getwd()

# EXERCISE 1

Rays_SP$L
ans1 = list("Losses List",3)
ans2 = matrix(data = c(1:15), nrow = 3, ncol = 5, byrow=TRUE)

# EXERCISE 2

hist(Rays_SP$L, probability=TRUE)
lines(density(Rays_SP$L, na.rm=TRUE), col="red")
shapiro.test(Rays_SP$L)
## ANSWER from shapiro test: W = 0.94352, p-value = 9.444e-07; the distribution not normal because the p-value is below .05.

# EXERCISE 3

data(iris)
head(iris)

## Histogram for Sepal Length 
hist(iris$Sepal.Length, probability=TRUE)
lines(density(iris$Sepal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Length)
### ANSWER: W = 0.97609, p-value = 0.01018; the distribution is not normal because the p-value is below .05.

## Histogram for Sepal Width
hist(iris$Sepal.Width, probability=TRUE)
lines(density(iris$Sepal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Sepal.Width)
### ANSWER: W = 0.98492, p-value = 0.1012; we don't have enough evidence to say that the distribution is not normal because the p-value is above .05.

## Histogram for Petal Length
hist(iris$Petal.Length, probability=TRUE)
lines(density(iris$Petal.Length, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Length)
### ANSWER: W = 0.87627, p-value = 7.412e-10; the distribution is not normal because the p-value is below .05.

## Histogram for Petal Width
hist(iris$Petal.Width, probability=TRUE)
lines(density(iris$Petal.Width, na.rm=TRUE), col="red")
shapiro.test(iris$Petal.Width)
### ANSWER: W = 0.90183, p-value = 1.68e-08; the distribution is not normal because the p-value is below .05.
