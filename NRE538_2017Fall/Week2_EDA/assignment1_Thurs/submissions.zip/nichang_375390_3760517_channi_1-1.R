#This file contains ony the codes required for exerices. Codes used for practice
#are stored in a separate file.

setwd("D:/UM/SNRE/Winter 2017/NRE 538 Statistics/Week 2 Lab")
Rays_SP=read.table("Rays_starter_1998_2015.csv",header=T,fill=T,sep=",")
head(Rays_SP)

#Exercise 1
#1.Picking Variables using "$"
Rays_SP$GS
Rays_SP$IP

#2.Create a list containing multiple types of data with list() 
list(Rays_SP$Name,Rays_SP$LOB,Rays_SP$GS)
#create a matrix with matrix()
matrix(Rays_SP$Season,nrow=4,ncol=47,byrow=FALSE,dimnames=NULL)


#Exercise 2 Plot the histogram of another variable plus density function 
#and test the normality of it.
hist(Rays_SP$GS)
hist(Rays_SP$GS,probability=TRUE)
lines(density(Rays_SP$GS,na.rm=TRUE),col="RED")
shapiro.test(Rays_SP$GS)

GS.mean=mean(Rays_SP$GS,na.rm=TRUE)
GS.sd=sd(Rays_SP$GS,na.rm=TRUE)
ks.test(Rays_SP$GS,"qnorm",GS.mean,GS.sd)

qqnorm(Rays_SP$GS)
qqline(Rays_SP$GS,col="RED")
library(car)
qqPlot(Rays_SP$GS)
#There is high porbability that GS data is not normally distributed.
#The Shapiro test p-value=7.603e-10<0.05,and there seem to be plenty of
#outliers in the QQ plot


#Exercise 3 Plot four histograms for each of the four variables in the Iris 
#flower data set (with density functions) and check the normality of them.
data(iris)
head(iris)

#Sepal Length
hist(iris$Sepal.Length)
hist(iris$Sepal.Length,probability=TRUE)
lines(density(iris$Sepal.Length,na.rm=TRUE),col="RED")
shapiro.test(iris$Sepal.Length)

Sepal.Length.mean=mean(iris$Sepal.Length,na.rm=TRUE)
Sepal.Length.sd=sd(iris$Sepal.Length,na.rm=TRUE)
ks.test(iris$Sepal.Length,"qnorm",Sepal.Length.mean,Sepal.Length.sd)

qqnorm(iris$Sepal.Length)
qqline(iris$Sepal.Length,col="RED")
#If this is a separate code I'd do library(car) again, but since I've
#done it when handling the baseball data, I didn't do it here.
qqPlot(iris$Sepal.Length)
#Sepal Length does not seem to be normally distributed.
#The shapiro test p-value=0.01<0.05, and there are a lot of outliers on QQ plot

#Sepal Width
hist(iris$Sepal.Width)
hist(iris$Sepal.Width,probability=TRUE)
lines(density(iris$Sepal.Width,na.rm=TRUE),col="RED")
shapiro.test(iris$Sepal.Width)

Sepal.Width.mean=mean(iris$Sepal.Width,na.rm=TRUE)
Sepal.Width.sd=sd(iris$Sepal.Width,na.rm=TRUE)
ks.test(iris$Sepal.Width,"qnorm",Sepal.Width.mean,Sepal.Width.sd)

qqnorm(iris$Sepal.Width)
qqline(iris$Sepal.Width,col="RED")
qqPlot(iris$Sepal.Width)
#There is good probability that sepal width is normally distributed
#as the shapiro test p-value=0.1>0.05 (There are several points outside
#the 95% confidential interval, but most of the data fell in)

#Petal Length
hist(iris$Petal.Length)
hist(iris$Petal.Length,probability=TRUE)
lines(density(iris$Petal.Length,na.rm=TRUE),col="RED")
shapiro.test(iris$Petal.Length)

Petal.Length.mean=mean(iris$Petal.Length,na.rm=TRUE)
Petal.Length.sd=sd(iris$Petal.Length,na.rm=TRUE)
ks.test(iris$Petal.Length,"qnorm",Petal.Length.mean,Petal.Length.sd)

qqnorm(iris$Petal.Length)
qqline(iris$Petal.Length,col="RED")
qqPlot(iris$Petal.Length)
#Petal Length does not seem to be normally distributed
#The shapiro test p-value=7.412e-10<0.05, and most of the data in QQ plot 
#are outliers

#Petal Width
hist(iris$Petal.Width)
hist(iris$Petal.Width,probability=TRUE)
lines(density(iris$Petal.Width,na.rm=TRUE),col="RED")
shapiro.test(iris$Petal.Width)

Petal.Width.mean=mean(iris$Petal.Width,na.rm=TRUE)
Petal.Width.sd=sd(iris$Petal.Width,na.rm=TRUE)
ks.test(iris$Petal.Width,"qnorm",Petal.Width.mean,Petal.Width.sd)

qqnorm(iris$Petal.Width)
qqline(iris$Petal.Width,col="RED")
qqPlot(iris$Petal.Width)
#Petal Width does not seem to be normally distributed
#The shapiro test p-value=1.68e-08<0.05, and most of the data in QQ plot 
#are outliers

#The ks tests issued warning about ties on a lot of occasions. How does this
#influence the test? And when ties are present, the test produce p values 
#only in some cases. Why is that?

